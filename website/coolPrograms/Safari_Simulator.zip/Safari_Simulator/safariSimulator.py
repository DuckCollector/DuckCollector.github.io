import tkinter as tk
import random
import math
class Pokemon:
    def __init__(self, pokemonName, dexNumber, catchRate, speed):
        self.pokemonName = pokemonName
        self.dexNumber = dexNumber
        self.catchRate = catchRate
        self.speed = speed
    def str(self):
        return self.pokemonName
        
class SafariSimulator(Pokemon, tk.Frame):
    def __init__(self, master=None, safari_ball=30, pokemon_caught=[]):
        self.safari_ball = safari_ball
        self.pokemon_caught = pokemon_caught
        open_file = open("pokedex.csv", "r")
        heading = open_file.readline()
        pokemon_list = open_file.readlines()
        self.all_data = []
        
        for i in range(len(pokemon_list)):
            pokemon_data = pokemon_list[i].split(',')
            self.all_data.append(pokemon_data)
            tk.Frame.__init__(self, master)
                
        master.minsize(width=375, height=450) 
        master.maxsize(width=375, height=450)
        master.title("Safari Zone Simulator")
        self.pack()
        self.createWidgets()

        self.nextPokemon()
        
    def createWidgets(self):
        #Run button
        self.runButton = tk.Button(self)
        self.runButton["text"] = "Run Away"
        self.runButton["command"] = self.nextPokemon
        self.runButton.pack()
        
        #Throw ball
        self.throwButton = tk.Button(self)
        self.throwButton["text"] = "Throw Safari Ball (" + "30" + " left)"
        self.throwButton["command"] = self.throwBall
        self.throwButton.pack()

        #Status
        self.statusLabel = tk.Label(bg="grey")
        self.statusLabel["text"] = "Welcome to the Safari Zone Simulator"
        self.statusLabel.pack(fill="x", padx=5, pady=5)
        
        #Encounter
        self.encounterLabel = tk.Label(self, bg="grey")
        self.encounterLabel["text"] = "You encounter a wild " + "pokemon"
        self.encounterLabel.pack(fill="x", padx=5, pady=5)

        #pokemonImageLabel
        self.image = tk.PhotoImage(file = "sprites/150.gif")
        self.pokemonImageLabel = tk.Label(self)
        self.pokemonImageLabel["image"] = self.image
        self.pokemonImageLabel.pack()


        #catchProbLabel
        self.catchProbLabel = tk.Label(bg="grey")
        self.catchProbLabel["text"] = "Your chance of catching it is " + "catch rate"
        self.catchProbLabel.pack(fill="x", padx=5, pady=5)

        #Run probability
        self.runLabel = tk.Label(bg="grey")
        self.runLabel["text"] = "Chance that " + "Pokemon" + " will run is " + "amount"
        self.runLabel.pack(fill="x", padx=5, pady=5)

    def nextPokemon(self):
        pokemon_number = random.randint(0, 151)
        new_pokemon_data = self.all_data[pokemon_number]
        self.dex_number = new_pokemon_data[0]
        self.pokemon_species = new_pokemon_data[1]
        self.catch_rate = new_pokemon_data[2]
        self.speed = new_pokemon_data[3]
        
        self.pokemon_img = "sprites/" + self.dex_number + ".gif"
        
        self.catch_rate__ = math.trunc((min((int(self.catch_rate) + 1), 151) / 449.5) * 100)

        self.run_rate = math.trunc((2*int(self.speed)/256)*100)
           
        self.encounterLabel["text"] = "You encounter a wild " + self.pokemon_species
        self.catchProbLabel["text"] = "Your chance of catching it is " + str(self.catch_rate__) + "%!"
            
        self.image = tk.PhotoImage(file = self.pokemon_img)
        self.pokemonImageLabel["image"] = self.image
       
        self.runLabel["text"] = "Chance that " + self.pokemon_species + " will run is " + str(self.run_rate) + "%"
        
    def throwBall(self):
        self.new_catch_rate = min((int(self.catch_rate) + 1), 151) / 449.5
        catch_num = random.random()
        rand_run = random.randint(0, 255)

        if catch_num < self.new_catch_rate:
            self.pokemon_caught.append(self.pokemon_species)
            self.safari_ball = self.safari_ball - 1
            self.throwButton["text"] = "Throw Safari Ball (" + str(self.safari_ball) + " left)"
            self.nextPokemon()
            self.statusLabel["text"] = "The previous Pokemon was caught!"
            
        else:
            if rand_run < self.run_rate:
                self.statusLabel["text"] = "Oop! the previous pokemon ran away!"
                self.safari_ball = self.safari_ball - 1
                self.throwButton["text"] = "Throw Safari Ball (" + str(self.safari_ball) + " left)"
                self.nextPokemon()
            else:
                self.encounterLabel["text"] = "Aargh! It escaped!"
                self.safari_ball = self.safari_ball - 1
                self.throwButton["text"] = "Throw Safari Ball (" + str(self.safari_ball) + " left)"

        if self.safari_ball == 0:
            self.endAdventure()

        
    def endAdventure(self):
        pokemon_got = ""
        for i in self.pokemon_caught:
            pokemon_got += (i+"\n")

        self.encounterLabel["text"] = "You're all out of balls, hope you had fun!"
        self.statusLabel.pack_forget()
        self.runLabel.pack_forget()
        self.runButton.pack_forget()
        self.throwButton.pack_forget()
        self.pokemonImageLabel.pack_forget()
        if len(self.pokemon_caught) == 0:
            self.catchProbLabel["text"] = "Oops! you caught 0 Pokemon!"
        else:
            self.catchProbLabel["text"] = "You caught " + str(len(self.pokemon_caught)) + " Pokemon:\n" + pokemon_got  





#DO NOT MODIFY: These lines start the app
app = SafariSimulator(tk.Tk())
app.mainloop()
