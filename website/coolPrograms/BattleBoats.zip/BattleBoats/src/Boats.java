//princ177 reddy215
//the Boats class stores the information of each individual boat
//for example, when we need to print the board the designation number will
//be used to print the boats id on the console
public class Boats {
    private int length;
    private int designation;
    int spacesTaken;
    //keeps track of how many spaces of the boat have not been hit
    //did not make private so it is much easier to access in
    //the BattleBoatsBoard class
    public Boats(int length, int des) {
        this.length = length;
        this.designation = des;
        this.spacesTaken = length;
    }
    public int getLength(){
        return this.length;
    }
    public int getDesignation(){
        return this.designation;
    }

}