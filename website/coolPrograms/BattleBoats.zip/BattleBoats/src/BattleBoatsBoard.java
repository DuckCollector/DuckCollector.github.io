//princ177 reddy215
public class BattleBoatsBoard {
    private int[][] board;
    //the gameboard that the game uses to check the player's board
    private String[][] playerBoard;
    //the gameboard that the player see and plays with
    //to try to win the game
    private int boardLength = 0;
    private int turn = 1;
    private int powerMissile = 0;
    private int powerDrone = 0;
    //the amount of times the user can use either missile or drone
    private int shipsLeft = 0;
    private int shotCounter = 0;//total shots taken in the game

    private String mode;
    private Boats[] boatsList;

    public BattleBoatsBoard(String mode) {
        if (mode.equals("1")) {
            board = new int[8][8];
            playerBoard = new String[8][8];
            boatsList = new Boats[5];
            boatsList[0] = new Boats(5, 1);
            boatsList[1] = new Boats(4, 2);
            boatsList[2] = new Boats(3, 3);
            boatsList[3] = new Boats(3, 4);
            boatsList[4] = new Boats(2, 5);
            this.shipsLeft = 5;
            this.boardLength = 8;
            this.powerMissile = 1;
            this.powerDrone = 1;
        } else if (mode.equals("2")) {
            board = new int[12][12];
            playerBoard = new String[12][12];
            boatsList = new Boats[10];
            boatsList[0] = new Boats(5, 1);
            boatsList[1] = new Boats(4, 2);
            boatsList[2] = new Boats(3, 3);
            boatsList[3] = new Boats(3, 4);
            boatsList[4] = new Boats(2, 5);
            boatsList[5] = new Boats(5, 6);
            boatsList[6] = new Boats(4, 7);
            boatsList[7] = new Boats(3, 8);
            boatsList[8] = new Boats(3, 9);
            boatsList[9] = new Boats(2, 10);
            this.shipsLeft = 10;
            this.boardLength = 12;
            this.powerMissile = 2;
            this.powerDrone = 2;
        }
        for (int i = 0; i < this.board.length; i++) {
            for (int j = 0; j < this.board[0].length; j++) {
                this.board[i][j] = 0;
                this.playerBoard[i][j] = "-";
            }
        }
        //creates the board as a 2D array composed of 0's (open spaces)
        //for the playerBoard the for loops fills it up with - representing
        //spaces that have not been checked yet


    }

    public void placeBoats() {
        for (int i = 0; i < boatsList.length; i++) {
            placeBoat(boatsList[i]);
        }
    }

    //method above places all the boats on the board
    public void placeBoat(Boats boat) {
        int randCol = (int) Math.floor(Math.random()*(board.length - boat.getLength() + 1));
        int randRow = (int) Math.floor(Math.random()*(board.length - boat.getLength() + 1));
        //int variable above will be used to choose a random column and row
        //where the boats is going to start.
        //board.length-boat.getLength()+1 prevents out of bound errors
        int direction = (int) Math.floor(Math.random()*3);
        //the direction integer corresponds to a random direction the boat is facing
        //if direction = 0, the boat will be horizontally placed
        //if direction = 1, the boat will be vertically placed
        //if direction = 2, the boat will be diagonally placed
        boolean placed = false;
        while (placed == false) {

            if (direction == 0 && canPlaceHorizontal(boat, randRow, randCol)) {
                for (int i = 0; i < boat.getLength(); i++) {
                    board[randRow][randCol + i] = boat.getDesignation();
                }
                placed = true;
            } else if (direction == 1 && canPlaceVertical(boat, randRow, randCol)) {
                for (int i = 0; i < boat.getLength(); i++) {
                    board[randRow + i][randCol] = boat.getDesignation();
                }
                placed = true;
            } else if (direction == 2 && canPlaceDiagonally(boat, randRow, randCol)) {
                for (int i = 0; i < boat.getLength(); i++) {
                    board[randRow + i][randCol + i] = boat.getDesignation();
                }
                placed = true;
            }
            randCol = (int) Math.floor(Math.random()*(board.length - boat.getLength() + 1));
            randRow = (int) Math.floor(Math.random()*(board.length - boat.getLength() + 1));
            direction = (int) Math.floor(Math.random()*3);
        }
    }

    //Method above places a singular boat
    public boolean canPlaceHorizontal(Boats boat, int row, int col) {

        for (int i = 0; i < boat.getLength(); i++) {
            if (board[row][col + i] != 0) {
                return false;
            }
        }
        //the for loops runs through a list of possible places the boat could be and
        //and checks is the spots are available
        return true;
    }

    public boolean canPlaceVertical(Boats boat, int row, int col) {
        for (int i = 0; i < boat.getLength(); i++) {

            if (board[row + i][col] != 0) {
                return false;
            }
        }
        return true;
    }

    public boolean canPlaceDiagonally(Boats boat, int row, int col) {
        for (int i = 0; i < boat.getLength(); i++) {

            if (board[row + i][col + i] != 0) {
                return false;
            }
        }
        return true;
    }

    public String fire(int row, int col) {
        //made this method return a string so that user can know
        //result when it is printed
        String result = "";
        if(row<0||row>=boardLength||col<0||col>=boardLength){
            result = "Out of bounds, penalty";
        } else if (board[row][col] != 0 && !playerBoard[row][col].equals("X")) {
            playerBoard[row][col] = "X";
            boatsList[board[row][col]- 1].spacesTaken--;
            if (boatsList[board[row][col] - 1].spacesTaken == 0) {
                result = "You destroyed the ship!";
                shipsLeft--;

            } else {
                result = "You hit the ship";
            }
            //case if the missile hits
        } else if (board[row][col] == 0) {
            playerBoard[row][col] = "U";
            //case if the missile misses
            result = "You missed";
        } else {
            result = "You already hit this spot, penalty";
        }
        this.shotCounter ++;
        this.turn++;
        return result;
    }

    public void display() {
        for (int i = 0; i < playerBoard.length; i++) {
            for (int j = 0; j < playerBoard.length; j++) {
                System.out.print(playerBoard[i][j] + ", ");
            }
            System.out.println("");
        }
    }

    public void print() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if(playerBoard[i][j].equals("X")){
                    System.out.print(playerBoard[i][j] + ", ");
                }else if(playerBoard[i][j].equals("U")){
                    System.out.print(playerBoard[i][j] + ", ");
                }else {
                    System.out.print(board[i][j] + ", ");
                }
            }
            System.out.println("");
        }

    }

    public void drone(int direction, int index) {
        int counter = 0;
        if (direction == 0) {
            for (int i = 0; i < board.length; i++) {
                if (board[i][index] != 0) {
                    counter++;
                }
            }
            System.out.println("Drone has scanned " + counter + " targets in the specified area.");
        } else if (direction == 1) {
            for (int j = 0; j < board.length; j++) {
                if (board[index][j] != 0) {
                    counter++;
                }
            }
            System.out.println("Drone has scanned " + counter + " targets in the specified area.");
        }
        powerDrone--;
        turn++;
    }
    public void missile(int row, int col){
        String results = "";
        for(int i = -1; i<2; i++){
            for(int j = -1; j<2; j++){
                if((0<=row+i)&&(row+i<this.boardLength)&& (0<=col+j) && (col+j<this.boardLength)) {
                    results = fire(row + i, col + j)+" at row: "+(row+i)+" and col: "+(col+j);
                    shotCounter--;
                    turn--;
                    if(results.split(" ")[1].equals("already")){
                        System.out.println("You already hit this spot at row: "+(row+i)+" and col: "+(col+j));

                    }else{
                        System.out.println(results);
                    }

                }
            }
        }
        powerMissile--;
        turn++;

    }

    public int getPowerMissile() {
        return powerMissile;
    }
    public int getPowerDrone(){
        return powerDrone;
    }

    public int getBoardLength() {
        return boardLength;
    }

    public int getShipsLeft() {
        return shipsLeft;
    }

    public int getTurn() {
        return turn;
    }
    public int getShotCounter(){
        return shotCounter;
    }

    public static void main(String[] args) {
    }
}