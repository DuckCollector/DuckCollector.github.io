//princ177 reddy215
import java.util.Scanner;
public class BattleBoatsGame {
    public static boolean canParseInt(String str){
        try{
            Integer.parseInt(str);
            return true;
        }catch (NumberFormatException s){
            return false;
        }
    }
    //checks to see if the str can be parsed into an int
    //credit for this helper method goes to Woot4Moo on stackoverflow
    //link:
    //https://stackoverflow.com/questions/8391979/does-java-have-a-int-tryparse-that-doesnt-throw-an-exception-for-bad-data
    public static boolean canSplit(String str){
        String split = "";
        try{
            split = str.split(" ")[1];
            return true;
        }catch(java.lang.ArrayIndexOutOfBoundsException s){
            return false;
        }
    }
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        System.out.println("Hello welcome to BattleBoats! Please enter 1 to play in standard mode or 2 to\n" +
                "play in expert.");
        String mode = s.next();
        while(!mode.equals("1") && !mode.equals("2")){
            System.out.println("Invalid input. Please enter 1 to play in standard mode or 2 to play in expert.");
            mode = s.next();
        }
        BattleBoatsBoard board = new BattleBoatsBoard(mode);
        board.placeBoats();
        System.out.println("Every turn you will get the option of using a missile, drone, or shot\n" +
                "you will get one drone or missile per game");
        while(board.getShipsLeft()>0){
            //this is the game loop
            System.out.println("Turn "+board.getTurn()+":");
            board.display();
            System.out.println("Drone, Missile, or Shot? (case not sensitive)");
            String attack = s.next();
            while((((!attack.equals("Drone")  && !attack.equals("drone"))||board.getPowerDrone()==0)
                    &&((!attack.equals("Missile")  && !attack.equals("missile"))||board.getPowerMissile() == 0))
                    && !attack.equals("Shot")&& !attack.equals("shot")){
                //this while loop is for shot selection between drone missile or shot
                //it allows for the program to prompt the user again if they type
                //an invalid input for their shot
                //
                //sorry about the complicated condition
                //if the player does not have any drone or missile shots left but types in drone or missile
                //the condition is met
                //if the player types in an invalid input the condition is also met
                if(attack.equals("print")){
                    System.out.println("Location of boats:");
                    board.print();
                    System.out.println("Drone, Missile, or Shot? (case not sensitive)");
                    attack = s.next();
                }
                else{
                    if(board.getPowerMissile() == 0){
                        System.out.println("You are out of missile shots");
                    }else if(board.getPowerDrone() ==0){
                        System.out.println("You are out of drone shots");
                    }
                    System.out.println("Invalid input!\n Drone, Missile, or Shot?");
                    attack = s.next();
                }
            }//end of shot selection loop


            if (attack.equals("Drone") || attack.equals("drone")){
                int dir = -1;
                System.out.println("Would you like to scan a row or column? Type in r for row or c for column");
                String direction = s.next();
                while(!direction.equals("r") && !direction.equals("c")){
                    //loop allows program to prompt user if they type in the wrong input
                    //or they type in print
                    if(direction.equals("print")){
                        System.out.println("Location of boats:");
                        board.print();
                        System.out.println("Would you like to scan a row or column? Type in r for row or c for column");
                        direction = s.next();
                    }
                    else {
                        System.out.println("Invalid input!\n Would you like to scan a row or column? Type in r for row or c for column");
                        direction = s.next();
                    }
                }//end of proper row selection loop
                if(direction.equals("r")){
                    dir = 1;
                }
                else{
                    dir = 0;
                }
                System.out.println("Which row or column would you like to scan?");
                String strRowCol = s.next();
                //made it a string so that user can type print without getting error
                int indexRowCol = -1;
                if(canParseInt(strRowCol)){
                    //can trace method call to the first method above main
                    //if statement above will check if strRowCol can be parsed into int so there is no error
                    indexRowCol = Integer.parseInt(strRowCol);
                }
                while(indexRowCol > board.getBoardLength()-1 || indexRowCol < 0){
                    //indexRowCol will be -1 if the user does not put in a string that can be parsed into a int
                    //this meet the condition of the while loop
                    if(strRowCol.equals("print")){
                        System.out.println("Location of boats:");
                        board.print();
                        System.out.println("Which row or column would you like to scan?");
                        strRowCol = s.next();
                        //prompts user again
                        if(canParseInt(strRowCol)){ //can trace method call to the first method above main
                            indexRowCol = Integer.parseInt(strRowCol);
                        }
                    }else {
                        System.out.println("Invalid Input. \nPlease type in a number within the boundaries of the board.");
                        strRowCol = s.next();
                        if(canParseInt(strRowCol)){
                            //can trace method call to the first method above main
                            indexRowCol = Integer.parseInt(strRowCol);
                        }
                    }
                }//end of proper index selection loop
                board.drone(dir, indexRowCol);

             //end of if user pick drone
            }else if(attack.equals("Missile")||attack.equals("missile")){
                System.out.println("What coordinate would you like to center the missile at?");
                System.out.println("Format:\nrow column");
                s.nextLine();
                //resolves the error of nextLine skipping
                //given by user2976389 at stackoverflow.com
                //link: https://stackoverflow.com/questions/23450524/java-scanner-doesnt-wait-for-user-input
                String coordinate = s.nextLine();
                //see line 98 for explanation
                int rowCor = -1;
                int colCor = -1;
                if(canSplit(coordinate)&&canParseInt(coordinate.split(" ")[0])&&canParseInt(coordinate.split(" ")[1])){
                    rowCor = Integer.parseInt(coordinate.split(" ")[0]);
                    colCor = Integer.parseInt(coordinate.split(" ")[1]);
                }
                //if the user input cannot be split properly or parsed into an int properly
                //rowCor and colCor will stay at negative one thus meeting
                //the conditions of the while loop below
                while(rowCor > board.getBoardLength()-1 || rowCor<0 || colCor > board.getBoardLength()-1 || colCor<0){
                    //conditions are met if rowCor and rowCol are out of bounds
                    if(coordinate.equals("print")){
                        System.out.println("Location of boats:");
                        board.print();
                        System.out.println("What coordinate would you like to center the missile at?");
                        System.out.println("Format:\nrow column");
                        coordinate = s.nextLine();
                        if(canSplit(coordinate)&&canParseInt(coordinate.split(" ")[0])&&canParseInt(coordinate.split(" ")[1])){
                            rowCor = Integer.parseInt(coordinate.split(" ")[0]);
                            colCor = Integer.parseInt(coordinate.split(" ")[1]);
                        }
                    }else {
                        System.out.println("Invalid Input. \nPlease type in a coordinate within the boundaries of the board.");
                        System.out.println("Format:\nrow column");
                        coordinate = s.nextLine();
                        if(canSplit(coordinate)&&canParseInt(coordinate.split(" ")[0])&&canParseInt(coordinate.split(" ")[1])){
                            rowCor = Integer.parseInt(coordinate.split(" ")[0]);
                            colCor = Integer.parseInt(coordinate.split(" ")[1]);
                        }
                    }
                }//end of proper coordinate selection loop
                board.missile(rowCor, colCor);

                //end of if user picks missile statement
            } else{
                System.out.println("What coordinate would you like to fire at?");
                System.out.println("Format:\nrow column");
                s.nextLine();
                String coordinate = s.nextLine();
                //see line 98 for explanation
                int rowCor = -1;
                int colCor = -1;
                if(canSplit(coordinate)&&canParseInt(coordinate.split(" ")[0])&&canParseInt(coordinate.split(" ")[1])){
                    rowCor = Integer.parseInt(coordinate.split(" ")[0]);
                    colCor = Integer.parseInt(coordinate.split(" ")[1]);
                }
                //see line 143 for explanation
                while(rowCor <0){

                    if(coordinate.equals("print")){
                        System.out.println("Location of boats:");
                        board.print();
                        System.out.println("What coordinate would you like to fire at?");
                        System.out.println("Format:\nrow column");
                        coordinate = s.nextLine();
                        if(canSplit(coordinate)&&canParseInt(coordinate.split(" ")[0])&&canParseInt(coordinate.split(" ")[1])){
                            rowCor = Integer.parseInt(coordinate.split(" ")[0]);
                            colCor = Integer.parseInt(coordinate.split(" ")[1]);
                        }
                    }else{
                        System.out.println("Invalid Input. \nPlease type in a coordinate pair in the format given");
                        System.out.println("Format:\nrow column");
                        coordinate = s.nextLine();
                        if(canSplit(coordinate)&&canParseInt(coordinate.split(" ")[0])&&canParseInt(coordinate.split(" ")[1])){
                            rowCor = Integer.parseInt(coordinate.split(" ")[0]);
                            colCor = Integer.parseInt(coordinate.split(" ")[1]);
                        }
                    }
                }//end of proper coordinate selection loop
                System.out.println(board.fire(rowCor, colCor));
            }//end of shot-else statement

        }//end of game loop
        System.out.println("You've sunk all the ships.");
        System.out.println("It took "+board.getShotCounter()+" shots");
        System.out.println("and "+board.getTurn()+" turns to sink all the ships.");

    }//end of main

}//end of class
