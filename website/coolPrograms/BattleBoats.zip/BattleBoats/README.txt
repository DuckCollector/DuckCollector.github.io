How to run and compile the code:
Run the BattleBoatsGame class and instructions should pop up

When you print to show the board capital U represents places you shot at and 0 represents the places that are open

Bug/defects:
There were no bugs detected while testing
Int spacesTaken in the boats class is public because it would have made the code
much harder to read when it is used in the BattleBoatGame