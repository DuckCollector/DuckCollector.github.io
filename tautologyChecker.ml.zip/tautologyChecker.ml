(*

Matt Princev

Tautology checker

See below for examples on how to run the program

*)

type proposition = 
  False | 
  True | 
  Var of string | 
  And of proposition * proposition | 
  Or of proposition * proposition | 
  Not of proposition | 
  Imply of proposition * proposition | 
  Equiv of proposition * proposition | 
  If of proposition * proposition * proposition ;;

let rec ifify p =
  match p
    with Not a -> If ( (ifify a), False, True ) |
    And (a, b) -> If ( (ifify a), (ifify b), False ) |
    Or (a, b) -> If ( (ifify a), True, (ifify b) )  |
    Imply (a, b) -> If ( (ifify a), (ifify b), True ) |
    Equiv (a, b) -> If ( (ifify a), (ifify b), ( If ( (ifify b), False, True ) ) ) |
    If (pi, a, b)  -> If ( (ifify pi), (ifify a), (ifify b) ) |
    _ -> p;;

let rec normalize c =
  let rec normalizing pi a b =
    match pi
      with If (pi', x, y) ->
        normalizing pi' ( If(x, a, b) ) ( If(y, a, b) )  |
      _ -> If (pi, (normalize a), (normalize b) )
  in match c 
    with If (originalPi, originalA, originalB) -> normalizing originalPi originalA originalB |
      _ -> c;;

let substitute c v b =
  let rec substituting c'=
    match c'
      with If (newC, newV, newB) ->
        If ( (substituting newC), (substituting newV), (substituting newB) ) |
      other -> 
        if c' = v
          then b
        else other
  in substituting c;;
      
let rec simplify c =
  match c
    with If (True, a, b ) -> simplify a |
    If (False, a, b) -> simplify b |
    If (pi, a, b) -> 
      let valA = simplify (substitute a pi True )
      in let valB = simplify (substitute b pi False )
        in if valA = True && valB = False
            then pi
          else if valA = valB
            then valA
          else If (pi, valA, valB) |
     _ -> c;;
          
let tautology p =
  simplify ( normalize ( ifify(p) ) ) = True;;


(*

Examples:

let tautTrue = Imply( (Not ( And ( (Var ("p") ), (Var ("q") ) ) ) ), ( Or ( ( Not( Var ("p") ) ), ( Not( Var ("q") ) ) ) ) );;
tautology(tautTrue);;

let otherTautTrue = Equiv ( (Not (Not (Var ("p") ) ) ), (Var ("p") ) );;
tautology(otherTautTrue);;

let tautFalse = Imply( (Not ( And ( (Var ("p") ), (Var ("q") ) ) ) ), ( Or ( (Var ("p") ), (Var ("q") ) ) ) );;
tautology(tautFalse);;

let tautOtherFalse = Not (Var ("p"));;
tautology(tautOtherFalse);;

Output:

val simplify : proposition -> proposition = <fun>
val tautology : proposition -> bool = <fun>
val tautTrue : proposition =
  Imply (Not (And (Var "p", Var "q")), Or (Not (Var "p"), Not (Var "q")))
- : bool = true
val otherTautTrue : proposition = Equiv (Not (Not (Var "p")), Var "p")
- : bool = true
val tautFalse : proposition =
  Imply (Not (And (Var "p", Var "q")), Or (Var "p", Var "q"))
- : bool = false
val tautOtherFalse : proposition = Not (Var "p")
- : bool = false

*)




  